<?php
date_default_timezone_set("Etc/GMT+8");

session_start();

require_once 'class.php';

$db = new db_class();
?>
<!DOCTYPE html>
<html lang="en">

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="css/sb-admin-2.css" rel="stylesheet">
<link href="css/custom.css" rel="stylesheet">

<!-- Custom styles for this page -->
<link href="css/dataTables.bootstrap4.css" rel="stylesheet">

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap Bundle JS (includes Popper.js) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Boxicons -->
<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.4.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

<!-- FontAwesome for Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- Bootstrap CSS (Add this inside the <head> tag) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GX1C1fVD06Bl0i6WSj1sxDoxJukG6Jg9tyR5dXlskv19q+WYFsN6m4hLuJ7uKfL6" crossorigin="anonymous">

<!-- Bootstrap JS Bundle (Add this before closing </body> tag) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoJihVSrGkUBkHgjLM0i02/5H2jIb0JiK/8Aks65XJUsGPb" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

<!-- Include DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

<!-- Include DataTables JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<!-- Include jQuery (required for DataTables) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>



<!-- My CSS -->
<link rel="stylesheet" href="style.css">

<title>Patients</title>

<style>
    /* Apply Times New Roman font globally */
    body {
        font-family: 'Verdana', sans-serif;
    }

    /* Align label and input side by side */
    .form-group-custom {
        display: flex;
        align-items: left;
        margin-bottom: 10px;
    }

    .form-group-custom label {
        width: 30%;
        margin-bottom: 0;
    }

    .form-group-custom input,
    .form-group-custom select,
    .form-group-custom textarea {
        flex: 1;
    }

    .rounded-container {
        border: 2px solid black;
        border-radius: 15px;
        padding: 20px;
        margin-top: 10px;
        background-color: #f9f9f9;
    }

    .rounded-container h5 {
        font-size: 1.25rem;
        margin-bottom: 15px;
        font-family: 'Verdana', sans-serif;
    }

    .rounded-container .form-group {
        margin-bottom: 15px;
    }

    .custom-select {
        width: 100px;
    }

    /* General form styles */
    .form-control,
    .col-form-label {
        font-family: 'Verdana', sans-serif;
        font-size: 10px;
        font-weight: normal;
    }

    .col-form-label {
        font-weight: normal;
        margin-right: 10px;
    }

    .form-control {
        height: 28px;
        padding: 2px 8px;
    }

    .mb-3 {
        margin-bottom: 8px !important;
    }

    .row {
        margin-top: 4px;
    }

    .form-group {
        margin-bottom: 8px !important;
    }

    h5 {
        font-size: 12px;
        font-family: 'Verdana', sans-serif;
    }

    select.form-control,
    input.form-control {
        font-size: 12px;
    }

    label {
        font-weight: bold;
    }

    /* styles.css */
    #toast-container {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 9999;
    }

    .toast {
        background-color: #4CAF50;
        /* Default green background */
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 16px;
        margin-top: 10px;
        opacity: 0;
        transition: opacity 0.5s ease-in-out;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        width: auto;
        max-width: 300px;
    }

    /* styles.css */
    .toast {
        background-color: green;
        /* Default green background for success */
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 16px;
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.5s ease-in-out;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        max-width: 300px;
        width: auto;
    }

    .toast.success {
        background-color: green;
        /* Green background for success */
    }

    .toast.error {
        background-color: red;
        /* Red background for error */
    }
</style>

</head>

<body>

    <script src="script.js"></script>

    <!-- SIDEBAR -->
    <section id="sidebar">
        <h1></h1>
        <h1></h1>
        <h1></h1>

        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">Menu</span>
        </a>

        <li class="has-submenu">
            <a href="patients.php">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                    <path d="M480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM160-240v-32q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v32q0 33-23.5 56.5T720-160H240q-33 0-56.5-23.5T160-240Zm80 0h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm240-320q33 0 56.5-23.5T560-640q0-33-23.5-56.5T480-720q-33 0-56.5 23.5T400-640q0 33 23.5 56.5T480-560Zm0-80Zm0 400Z" />
                </svg>
                <span class="text">Registration</span>
            </a>
        </li>

        <li class="has-submenu">
            <a href="addcalls.php">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                    <path d="M160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h207q16 0 30.5 6t25.5 17l57 57h320q33 0 56.5 23.5T880-640v400q0 33-23.5 56.5T800-160H160Zm0-80h640v-400H447l-80-80H160v480Zm0 0v-480 480Zm400-160v40q0 17 11.5 28.5T600-320q17 0 28.5-11.5T640-360v-40h40q17 0 28.5-11.5T720-440q0-17-11.5-28.5T680-480h-40v-40q0-17-11.5-28.5T600-560q-17 0-28.5 11.5T560-520v40h-40q-17 0-28.5 11.5T480-440q0 17 11.5 28.5T520-400h40Z" />
                </svg>
                <span class="text">Appointments</span>
            </a>
        </li>


        <li class="has-submenu">
            <a href="#" class="submenu-toggle">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                    <path d="M200-80q-33 0-56.5-23.5T120-160v-560q0-33 23.5-56.5T200-800h40v-40q0-17 11.5-28.5T280-880q17 0 28.5 11.5T320-840v40h320v-40q0-17 11.5-28.5T680-880q17 0 28.5 11.5T720-840v40h40q33 0 56.5 23.5T840-720v560q0 33-23.5 56.5T760-80H200Zm0-80h560v-400H200v400Zm0-480h560v-80H200v80Zm0 0v-80 80Zm280 240q-17 0-28.5-11.5T440-440q0-17 11.5-28.5T480-480q17 0 28.5 11.5T520-440q0 17-11.5 28.5T480-400Zm-160 0q-17 0-28.5-11.5T280-440q0-17 11.5-28.5T320-480q17 0 28.5 11.5T360-440q0 17-11.5 28.5T320-400Zm320 0q-17 0-28.5-11.5T600-440q0-17 11.5-28.5T640-480q17 0 28.5 11.5T680-440q0 17-11.5 28.5T640-400ZM480-240q-17 0-28.5-11.5T440-280q0-17 11.5-28.5T480-320q17 0 28.5 11.5T520-280q0 17-11.5 28.5T480-240Zm-160 0q-17 0-28.5-11.5T280-280q0-17 11.5-28.5T320-320q17 0 28.5 11.5T360-280q0 17-11.5 28.5T320-240Zm320 0q-17 0-28.5-11.5T600-280q0-17 11.5-28.5T640-320q17 0 28.5 11.5T680-280q0 17-11.5 28.5T640-240Z" />
                </svg>
                <span class="text">Assessment</span>
                <i class='bx bx-chevron-down dropdown-icon'></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="assesnutrition.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">Nutrition</span>
                    </a>
                </li>
                <li>
                    <a href="assespsycho.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">pyschosocial</span>
                    </a>
                </li>
                <li>
                    <a href="asseschronic.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">Chronic</span>
                    </a>
                </li>
                <li>
                    <a href="assesmeds.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">Medication</span>
                    </a>
                </li>
            </ul>
        </li>
        <li class="has-submenu">
            <a href="#" class="submenu-toggle">
                <i class='bx bxs-dashboard'></i>


                <span class="text">Settings</span>
                <i class='bx bx-chevron-down dropdown-icon'></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="addbranch.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">Branch</span>
                    </a>
                </li>
                <li>
                    <a href="addscheme.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">schemes</span>
                    </a>
                </li>
                <li>
                    <a href="addroutes.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">routes</span>
                    </a>
                </li>
                <li>
                    <a href="addmedication.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">Medications</span>
                    </a>
                </li>
                <li>
                    <a href="addspecialist.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">specialists</span>
                    </a>
                </li>
                <li>
                    <a href="addprocedure.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">procedures</span>
                    </a>
                </li>
                <li>
                    <a href="addcohort.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">cohorts</span>
                    </a>
                </li>
                <li>
                    <a href="adduser.php">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">users</span>
                    </a>
                </li>
                <li>
                    <a href="adddiagnosis.php"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                            <path d="m221-313 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-228q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm0-320 142-142q12-12 28-11.5t28 12.5q11 12 11 28t-11 28L250-548q-12 12-28 12t-28-12l-86-86q-11-11-11-28t11-28q11-11 28-11t28 11l57 57Zm339 353q-17 0-28.5-11.5T520-320q0-17 11.5-28.5T560-360h280q17 0 28.5 11.5T880-320q0 17-11.5 28.5T840-280H560Zm0-320q-17 0-28.5-11.5T520-640q0-17 11.5-28.5T560-680h280q17 0 28.5 11.5T880-640q0 17-11.5 28.5T840-600H560Z" />
                        </svg>

                        <span class="text">diagnosis</span>
                    </a>
                </li>
            </ul>
        </li>
        <li class="has-submenu">
            <a href="summary.php">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                    <path d="M480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM160-240v-32q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v32q0 33-23.5 56.5T720-160H240q-33 0-56.5-23.5T160-240Zm80 0h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm240-320q33 0 56.5-23.5T560-640q0-33-23.5-56.5T480-720q-33 0-56.5 23.5T400-640q0 33 23.5 56.5T480-560Zm0-80Zm0 400Z" />
                </svg>
                <span class="text">Summary</span>
            </a>
        </li>



    </section>
    <!-- SIDEBAR -->

    <!-- Add the following CSS and JavaScript for submenu toggle functionality -->
    <style>
        .has-submenu .submenu {
            display: none;
            list-style: none;
            padding-left: 20px;
        }

        .has-submenu .submenu li a {
            font-size: 0.9rem;
        }

        .has-submenu.active .submenu {
            display: block;
        }

        .dropdown-icon {
            margin-left: auto;
            transition: transform 0.3s ease;
        }

        .has-submenu.active .dropdown-icon {
            transform: rotate(180deg);
        }
    </style>

    <script>
        document.querySelectorAll('.submenu-toggle').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const parent = this.parentElement;
                parent.classList.toggle('active');
            });
        });
    </script>



    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">

                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>
        <!-- NAVBAR -->
        <main>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Pyschosocial assesment </h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                        <button type="button" style="border: none; background: none; cursor: pointer;" data-toggle="modal" data-target="#patientModal" aria-label="Add Patient">
                            <i class='bx bx-plus'></i>
                        </button>
                    </div>
                    <table id="patientTable" class="table table-bordered">
                        <thead>
                            <tr>
                                <th></th>

                                <th>Patient Name</th>


                                <th>Assesment</th>
                                <th>Patient Status</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Fetch patient records from the database
                            $visit = $db->AssesPsychosocial();

                            $rowNumber = 0; // Initialize row number

                            while ($fetch = $visit->fetch_array(MYSQLI_ASSOC)) {
                                // Check if the assessment is not 'Chronic' and add a hidden class to hide the row
                                $hiddenClass = ($fetch['assessment'] !== 'Psychosocial') ? 'hidden-row' : '';

                            ?>
                                <tr class="<?php echo $hiddenClass; ?>">

                                    <td><?php echo $rowNumber++; ?></td>


                                    <td><?php echo $fetch['firstname'] . ' ' . $fetch['lastname']; ?></td>

                                    <td><?php echo $fetch['assessment']; ?></td>
                                    <td><?php echo $fetch['patient_status']; ?></td>

                                    <td>
                                        <div class="d-flex justify-content-between">
                                            <button type="button" class="btn btn-info" data-toggle="modal" data-target="#editModal<?php echo $fetch['id']; ?>" style="background-color: black; color: white;">Edit</button>

                                            <!-- Button to trigger modal for delete -->
                                            <button class="btn btn-danger" data-toggle="modal" data-target="#deleteModal<?php echo $fetch['id']; ?>">Delete</button>
                                            <!-- Modal for Deletion Confirmation -->
                                        </div>

                                        <div class="modal fade" id="deleteModal<?php echo $fetch['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Delete Patient Record</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Are you sure you want to delete this patient record?</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <a href="deletechronic.php?id=<?php echo $fetch['id']; ?>" class="btn btn-danger">Delete</a>
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </td>


                                    <!-- Add the following CSS to hide rows -->
                                    <style>
                                        .hidden-row {
                                            display: none;
                                        }
                                    </style>

                                    <!-- Modal Content -->
                                    <div class="modal fade" id="nweditModal<?php echo $fetch['patient_id']; ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo $fetch['patient_id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>

                                                <form action="savepsychosocial.php" method="POST">
                                                    <div class="modal-body">
                                                        <div class="rounded-container">
                                                            <!-- Hidden Field -->
                                                            <input type="hidden" name="patient_id" value="<?php echo $fetch['patient_id']; ?>">

                                                            <h5>Patient Bio Details</h5>
                                                            <div class="row">
                                                                <!-- First Column -->
                                                                <div class="col-md-6">
                                                                    <div class="form-group d-flex">
                                                                        <label for="edit_first_name" class="w-50">First Name</label>
                                                                        <input type="text" class="form-control w-50" id="edit_first_name" name="first_name" value="<?php echo $fetch['firstname']; ?>" required>
                                                                    </div>

                                                                    <div class="form-group d-flex">
                                                                        <label for="edit_phone_no" class="w-50">Phone Number</label>
                                                                        <input type="tel" class="form-control w-50" id="edit_phone_no" name="phone_no" value="<?php echo $fetch['phone_no']; ?>" required>
                                                                    </div>

                                                                    <div class="form-group d-flex">
                                                                        <label for="scheme_id" class="w-50">Scheme</label>
                                                                        <select class="form-control w-50" id="scheme_id" name="scheme_id" required>
                                                                            <option value="" disabled selected>Select scheme</option>
                                                                            <?php
                                                                            $schemes = $db->display_schemes();
                                                                            if ($schemes !== false) {
                                                                                foreach ($schemes as $scheme) {
                                                                                    echo "<option value='{$scheme['scheme_id']}'>{$scheme['scheme_name']} - {$scheme['payment_method']}</option>";
                                                                                }
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label for="diagnosis" class="w-50">Diagnosis</label>
                                                                        <input type="text" class="form-control w-50" id="diagnois" name="diagnosis_id" value="<?php echo $fetch['diagnosis']; ?>" required>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">status</label>
                                                                        <select class="form-control w-50" name="patient_status">
                                                                            <option value="active">Active</option>
                                                                            <option value="semi active">Semi Active</option>
                                                                            <option value="not active">Not Active</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label for="edit_patient_no" class="w-50">Patient No.</label>
                                                                        <input type="tel" class="form-control w-50" id="edit_patient_no" name="patient_no" value="<?php echo $fetch['patient_no']; ?>" required>
                                                                    </div>

                                                                </div>

                                                                <!-- Second Column -->
                                                                <div class="col-md-6">
                                                                    <div class="form-group d-flex">
                                                                        <label for="edit_last_name" class="w-50">Last Name</label>
                                                                        <input type="text" class="form-control w-50" id="edit_last_name" name="last_name" value="<?php echo $fetch['lastname']; ?>" required>
                                                                    </div>
                                                                    <div class="orm-group d-flex">
                                                                        <label for="edit_dob" class="w-50"> Date of Birth</label>
                                                                        <input type="date" class="form-control" id="edit_dob" name="dob" value="<?php echo $fetch['dob']; ?>" required>
                                                                    </div>

                                                                    <div class="form-group d-flex">
                                                                        <label for="edit_age" class="w-50">Age</label>
                                                                        <input type="text" class="form-control w-50" id="edit_age" name="age" value="<?php echo $fetch['age']; ?>" readonly>
                                                                    </div>
                                                                    <div class="orm-group d-flex">
                                                                        <label for="Payment_method" class="w-50">Payment Method</label>
                                                                        <select class="form-select" id="Payment_method" name="Payment_method" required>
                                                                            <option value="" disabled selected>Select Payment Method</option>
                                                                            <?php
                                                                            // Fetch payment methods from the database
                                                                            $payment_methods = $db->display_payment_methods();
                                                                            if ($payment_methods !== false) {
                                                                                foreach ($payment_methods as $method) {
                                                                                    echo "<option value='{$method['scheme']}'>{$method['payment_method']}</option>";
                                                                                }
                                                                            } else {
                                                                                echo "<option value='' disabled>Error fetching payment methods</option>";
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>



                                                        <div class="rounded-container">
                                                            <h5>Psychosocial Assessment</h5>
                                                            <div class="row">
                                                                <!-- First Column for Psychosocial Details -->
                                                                <div class="col-md-6">
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Last Visit</label>
                                                                        <input type="date" class="form-control w-50" name="last_visit" required>
                                                                    </div>
                                                                    <div class=" form-group d-flex">
                                                                        <label class="w-50">Next Review</label>
                                                                        <input type="date" class="form-control w-50" name="next_review" required>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Educational Level</label>
                                                                        <select class="form-control w-50" name="educational_level" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Career/Business</label>
                                                                        <select class="form-control w-50" name="career_business" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Marital Status</label>
                                                                        <select class="form-control w-50" name="marital_status" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Relationship Status</label>
                                                                        <select class="form-control w-50" name="relationship_status" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Primary Relationship Status</label>
                                                                        <select class="form-control w-50" name="primary_relationship_status" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Ability to Enjoy Leisure Activities</label>
                                                                        <select class="form-control w-50" name="ability_to_enjoy_leisure_activities" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Spirituality</label>
                                                                        <select class="form-control w-50" name="spirituality" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Substance Use</label>
                                                                        <select class="form-control w-50" name="substance_use" required>
                                                                            <option value="Occasional">Occasional</option>
                                                                            <option value="Monthly Use">Monthly Use</option>
                                                                            <option value="Weekly Use">Weekly Use</option>
                                                                            <option value="Daily Use">Daily Use</option>
                                                                            <option value="No Use">No Use</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Revenue</label>
                                                                        <input type="number" class="form-control w-50" name="revenue" required>
                                                                    </div>
                                                                </div>


                                                                <!-- Second Column for Psychosocial Details -->
                                                                <div class="col-md-6">

                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Substance Used</label>
                                                                        <select class="form-control w-50" name="substance_used" required>
                                                                            <option value="Alcohol">Alcohol</option>
                                                                            <option value="Tobacco">Tobacco</option>
                                                                            <option value="Heroin">Heroin</option>
                                                                            <option value="Cocaine">Cocaine</option>
                                                                            <option value="Cannabis">Cannabis</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Assessment Remarks</label>
                                                                        <select class="form-control w-50" name="assessment_remarks" required>
                                                                            <option value="Well Managed">Well Managed</option>
                                                                            <option value="Occasional Support Required">Occasional Support Required</option>
                                                                            <option value="Regular Support Required">Regular Support Required</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Level of Self Esteem</label>
                                                                        <select class="form-control w-50" name="level_of_self_esteem" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Sex Life</label>
                                                                        <select class="form-control w-50" name="sex_life" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Ability to Cope and Recover from Life’s Disappointments</label>
                                                                        <select class="form-control w-50" name="ability_to_cope_and_recover" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Rate of Personal Development and Growth</label>
                                                                        <select class="form-control w-50" name="rate_of_personal_development_growth" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Achievement of Balance in Your Life</label>
                                                                        <select class="form-control w-50" name="achievement_of_balance_in_life" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group d-flex">
                                                                        <label class="w-50">Social Support System</label>
                                                                        <select class="form-control w-50" name="social_support_system" required>
                                                                            <option value="Very Satisfied">Very Satisfied</option>
                                                                            <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                            <option value="Indifferent">Indifferent</option>
                                                                            <option value="Mildly disappointed">Mildly disappointed</option>
                                                                            <option value="Very disappointed">Very disappointed</option>
                                                                        </select>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <div class="col-12 text-center">
                                                            <input type="submit" name="update" class="btn btn-info btn-large" value="Submit" style="background-color: black; color: white;">

                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div><!-- Delete Modal -->

                                    <div class="modal fade" id="deleteModal<?php echo $fetch['chronic_id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Delete Branch</h5>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete this record?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <div class="col-12 text-center">
                                                        <a href="deletechronic.php?id=<?php echo $fetch['chronic_id']; ?>" class="btn btn-danger" style="background-color: red; color: white;">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>


                                <?php } ?>
                        </tbody>
                    </table>
                </div>

                <script>
                    $(document).ready(function() {
                        $('#patientTable').DataTable({
                            "searching": true,
                            "paging": true,
                            "ordering": true,
                            "info": true,
                            "language": {
                                "emptyTable": "",
                                "zeroRecords": ""
                            },
                            "pageLength": 5 // Set the number of entries to 5
                        });
                    });



                    $(document).ready(function() {
                        // Handle delete button click
                        $('#patientTable').on('click', '.delete-btn', function() {
                            var patientId = $(this).data('id'); // Get the patient ID from data-id attribute

                            // Confirm deletion
                            if (confirm('Are you sure you want to delete this record?')) {
                                // Send AJAX request to delete the patient record
                                $.ajax({
                                    url: 'deletepsychosocial.php', // PHP script to handle deletion
                                    type: 'POST',
                                    data: {
                                        id: patientId
                                    }, // Send the patient ID to the server
                                    success: function(response) {
                                        if (response === 'success') {
                                            alert('Record deleted successfully');
                                            // Remove the row from the table
                                            $('#patientTable').find('tr[data-id="' + patientId + '"]').remove();
                                        } else {
                                            alert('Error deleting record');
                                        }
                                    },
                                    error: function() {
                                        alert('There was an error with the deletion.');
                                    }
                                });
                            }
                        });
                    });
                </script>



                <div class="todo">
                    <div class="todo">
                        <div class="head">
                            <h3>Call List</h3>

                        </div>

                        <!-- Right-aligned search input box -->
                        <div style="display: flex; justify-content: flex-end; margin-bottom: 5px;">
                            <form action="#">
                                <input type="search" placeholder="Search..." id="searchInput" onkeyup="filterList()">
                                <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                            </form>
                        </div>


                        <div style="max-height: 300px; overflow-y: auto; scrollbar-width: none; -ms-overflow-style: none; padding: 15px; border-radius: 5px;">
                            <ul class="todo-list" id="todoList">
                                <?php
                                // Fetch patient records from the database
                                $calls = $db->display_calls_patient();
                                $displayedPatients = []; // Array to track displayed patient IDs

                                while ($fetch = $calls->fetch_array(MYSQLI_ASSOC)) {
                                    // Check if the patient_id has already been displayed
                                    if (in_array($fetch['patient_id'], $displayedPatients)) {
                                        continue; // Skip this record if it has already been displayed
                                    }

                                    // Add the patient_id to the displayed array
                                    $displayedPatients[] = $fetch['patient_id'];
                                ?>
                                    <li class="completed">
                                        <p>
                                            <strong>Patient:</strong> <?php echo htmlspecialchars($fetch['firstname']); ?> <br>
                                            <strong>Phone:</strong> <?php echo htmlspecialchars($fetch['phone_no']); ?> <br>
                                            <strong>Call Results:</strong> <?php echo htmlspecialchars($fetch['call_results']); ?> <br>
                                            <strong>Refill Date:</strong> <?php echo htmlspecialchars($fetch['refill_date']); ?> <br>
                                        </p>
                                        <div class="d-flex gap-2">
                                            <!-- Button to trigger the modal -->
                                            <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#editModal<?php echo htmlspecialchars($fetch['patient_id']); ?>">Assess</button>
                                        </div>
                                    </li>

                                    <!-- Modal for editing the patient details -->
                                    <div class="modal fade" id="editModal<?php echo htmlspecialchars($fetch['patient_id']); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo htmlspecialchars($fetch['patient_id']); ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="editModalLabel<?php echo htmlspecialchars($fetch['patient_id']); ?>">Edit Patient Details</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="savepsychosocial.php" method="POST">
                                                        <div class="modal-body">
                                                            <div class="rounded-container">
                                                                <!-- Hidden Field -->
                                                                <input type="hidden" name="patient_id" value="<?php echo $fetch['patient_id']; ?>">

                                                                <h5>Patient Bio Details</h5>
                                                                <div class="row">
                                                                    <!-- First Column -->
                                                                    <div class="col-md-6">
                                                                        <div class="form-group d-flex">
                                                                            <label for="edit_first_name" class="w-50">First Name</label>
                                                                            <input type="hidden" name="patient_id" value="<?php echo $fetch['patient_id']; ?>">
                                                                            <!-- Hidden Field -->
                                                                            <input type="hidden" name="patient_id" value="<?php echo $fetch['patient_id']; ?>">
                                                                            <input type="text" class="form-control w-50" id="edit_first_name" name="first_name" value="<?php echo $fetch['firstname']; ?>" readonly>
                                                                        </div>

                                                                        <div class="form-group d-flex">
                                                                            <label for="edit_phone_no" class="w-50">Phone Number</label>
                                                                            <input type="tel" class="form-control w-50" id="edit_phone_no" name="phone_no" value="<?php echo $fetch['phone_no']; ?>" readonly>
                                                                        </div>



                                                                        <!-- New Revenue Field -->


                                                                        <div class="form-group d-flex">
                                                                            <label for="diagnosis" class="w-50">Diagnosis</label>
                                                                            <input type="text" class="form-control w-50" id="diagnosis" name="diagnosis_id" value="<?php echo $fetch['diagnosis']; ?>" readonly>
                                                                        </div>

                                                                        <div class="form-group d-flex">
                                                                            <label for="edit_patient_no" class="w-50">Patient No.</label>
                                                                            <input type="tel" class="form-control w-50" id="edit_patient_no" name="patient_no" value="<?php echo $fetch['patient_no']; ?>" readonly>
                                                                        </div>
                                                                    </div>

                                                                    <!-- Second Column -->
                                                                    <div class="col-md-6">
                                                                        <div class="form-group d-flex">
                                                                            <label for="edit_last_name" class="w-50">Last Name</label>
                                                                            <input type="text" class="form-control w-50" id="edit_last_name" name="last_name" value="<?php echo $fetch['lastname']; ?>" readonly>
                                                                        </div>

                                                                        <div class="form-group d-flex">
                                                                            <label for="edit_dob" class="w-50">Date of Birth</label>
                                                                            <input type="date" class="form-control w-50" id="edit_dob" name="dob" value="<?php echo $fetch['dob']; ?>" readonly>
                                                                        </div>

                                                                        <div class="form-group d-flex">
                                                                            <label for="edit_age" class="w-50">Age</label>
                                                                            <input type="text" class="form-control w-50" id="edit_age" name="age" value="<?php echo $fetch['age']; ?>" readonly>
                                                                        </div>


                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Status</label>
                                                                            <input type="patient_status" class="form-control w-50" id="edit_patient_status" name="patient_status" value="<?php echo $fetch['patient_status']; ?>" readonly>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="rounded-container">
                                                                <h5>Psychosocial Assessment</h5>
                                                                <div class="row">
                                                                    <!-- First Column for Psychosocial Details -->
                                                                    <div class="col-md-6">
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Visit Date</label>
                                                                            <input type="date" class="form-control w-50" name="visit_date" required>
                                                                        </div>
                                                                        <div class=" form-group d-flex">
                                                                            <label class="w-50">Next Review</label>
                                                                            <input type="date" class="form-control w-50" name="next_review" required>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Educational Level</label>
                                                                            <select class="form-control w-50" name="educational_level" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Career/Business</label>
                                                                            <select class="form-control w-50" name="career_business" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Marital Status</label>
                                                                            <select class="form-control w-50" name="marital_status" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Relationship Status</label>
                                                                            <select class="form-control w-50" name="relationship_status" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Primary Relationship Status</label>
                                                                            <select class="form-control w-50" name="primary_relationship_status" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Ability to Enjoy Leisure Activities</label>
                                                                            <select class="form-control w-50" name="ability_to_enjoy_leisure_activities" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Spirituality</label>
                                                                            <select class="form-control w-50" name="spirituality" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Substance Use</label>
                                                                            <select class="form-control w-50" name="substance_use" required>
                                                                                <option value=""></option>
                                                                                <option value="Occasional">Occasional</option>
                                                                                <option value="Monthly Use">Monthly Use</option>
                                                                                <option value="Weekly Use">Weekly Use</option>
                                                                                <option value="Daily Use">Daily Use</option>
                                                                                <option value="No Use">No Use</option>
                                                                            </select>
                                                                        </div>

                                                                    </div>

                                                                    <!-- Second Column for Psychosocial Details -->
                                                                    <div class="col-md-6">

                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Substance Used</label>
                                                                            <select class="form-control w-50" name="substance_used" required>
                                                                                <option value=""></option>
                                                                                <option value="Alcohol">Alcohol</option>
                                                                                <option value="Tobacco">Tobacco</option>
                                                                                <option value="Heroin">Heroin</option>
                                                                                <option value="Cocaine">Cocaine</option>
                                                                                <option value="Cannabis">Cannabis</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Assessment Remarks</label>
                                                                            <select class="form-control w-50" name="assessment_remarks" required>
                                                                                <option value=""></option>
                                                                                <option value="Well Managed">Well Managed</option>
                                                                                <option value="Occasional Support Required">Occasional Support Required</option>
                                                                                <option value="Regular Support Required">Regular Support Required</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Level of Self Esteem</label>
                                                                            <select class="form-control w-50" name="level_of_self_esteem" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Sex Life</label>
                                                                            <select class="form-control w-50" name="sex_life" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Ability to Cope and Recover from Life’s Disappointments</label>
                                                                            <select class="form-control w-50" name="ability_to_cope_and_recover" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Rate of Personal Development and Growth</label>
                                                                            <select class="form-control w-50" name="rate_of_personal_development_growth" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Achievement of Balance in Your Life</label>
                                                                            <select class="form-control w-50" name="achievement_of_balance_in_life" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group d-flex">
                                                                            <label class="w-50">Social Support System</label>
                                                                            <select class="form-control w-50" name="social_support_system" required>
                                                                                <option value=""></option>
                                                                                <option value="Very Satisfied">Very Satisfied</option>
                                                                                <option value="Mildly Satisfied">Mildly Satisfied</option>
                                                                                <option value="Indifferent">Indifferent</option>
                                                                                <option value="Mildly disappointed">Mildly disappointed</option>
                                                                                <option value="Very disappointed">Very disappointed</option>
                                                                            </select>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- Revenue -->


                                                            <div class="rounded-container">
                                                                <div class="row">
                                                                    <!-- First Column - Revenue -->
                                                                    <div class="col-md-6">
                                                                        <div class="form-group d-flex">
                                                                            <label for="scheme_id" class="w-50">Scheme</label>
                                                                            <select class="form-control w-50" id="scheme_id" name="scheme_id" required>
                                                                                <option value=""></option>
                                                                                <?php
                                                                                $schemes = $db->display_schemes();
                                                                                if ($schemes !== false) {
                                                                                    foreach ($schemes as $scheme) {
                                                                                        echo "<option value='{$scheme['scheme_id']}'>{$scheme['scheme_name']} - {$scheme['payment_method']}</option>";
                                                                                    }
                                                                                }
                                                                                ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <!-- Third Column - Payment Method -->
                                                                    <div class="col-md-6">
                                                                        <div class="form-group d-flex">
                                                                            <label for="revenue" class="w-50">Revenue</label>
                                                                            <input type="number" class="form-control w-50" id="revenue" name="revenue" required>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>


                                                        <div class="modal-footer">
                                                            <div class="col-12 text-center">
                                                                <!-- Submit Button -->
                                                                <button type="submit" name="submit" class="btn btn-info btn-large" style="background-color: black; color: white;">
                                                                    Submit
                                                                </button>

                                                                <!-- Close Form Button -->
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                }
                                ?>
                            </ul>
                        </div>

                        <script>
                            function filterList() {
                                var input, filter, ul, li, p, i, txtValue;
                                input = document.getElementById('searchInput');
                                filter = input.value.toUpperCase();
                                ul = document.getElementById("todoList");
                                li = ul.getElementsByTagName('li');

                                // Loop through all list items and hide those that don't match the search query
                                for (i = 0; i < li.length; i++) {
                                    p = li[i].getElementsByTagName("p")[0];
                                    if (p) {
                                        txtValue = p.textContent || p.innerText;
                                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                            li[i].style.display = "";
                                        } else {
                                            li[i].style.display = "none";
                                        }
                                    }
                                }
                            }
                        </script>




        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->



</body>

</html>